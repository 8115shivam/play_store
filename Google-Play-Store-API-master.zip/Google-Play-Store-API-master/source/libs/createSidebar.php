<?php
	$top_trending_apps = $play_store_api->topTrendingApps(1);
	$top_new_free_apps = $play_store_api->topNewFreeApps(1);
	$top_new_paid_apps = $play_store_api->topNewPaidApps(1);
?>