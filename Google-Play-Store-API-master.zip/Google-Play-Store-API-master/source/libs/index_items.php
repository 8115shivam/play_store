<?php
	$topGrossingApps = $play_store_api->topGrossingApps(1);
	$topFreeGames = $play_store_api->topFreeGames(1);
	$topPaidGames = $play_store_api->topPaidGames(1);
	$staffPicks = $play_store_api->staffPicks(1);
	$staffPicksForTablet = $play_store_api->staffPicksForTablet(1);
?>